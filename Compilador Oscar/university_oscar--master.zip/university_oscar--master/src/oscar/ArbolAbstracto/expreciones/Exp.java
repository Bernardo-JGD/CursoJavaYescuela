/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package oscar.ArbolAbstracto.expreciones;

import oscar.ArbolAbstracto.otros.Estatuto;

/**
 *
 * @author OSCAR
 */
public abstract class Exp extends Estatuto{
    public abstract int eval();
}
