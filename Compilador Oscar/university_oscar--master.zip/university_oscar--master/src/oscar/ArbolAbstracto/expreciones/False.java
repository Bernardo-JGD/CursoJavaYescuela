/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package oscar.ArbolAbstracto.expreciones;

/**
 *
 * @author OSCAR
 */
public class False extends Exp{
    
    public int eval(){
        return 0;
    }
}
