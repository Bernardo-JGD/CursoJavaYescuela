/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package oscar.ArbolAbstracto.tipos;

/**
 *
 * @author OSCAR
 */
public class BooleanTipo extends Tipo{
    @Override
    public String toString(){
        return "BooleanTipo\n";
    }
}
