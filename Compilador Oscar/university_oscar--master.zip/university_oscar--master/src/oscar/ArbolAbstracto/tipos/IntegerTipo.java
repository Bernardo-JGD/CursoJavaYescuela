/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package oscar.ArbolAbstracto.tipos;

/**
 *
 * @author OSCAR
 */
public class IntegerTipo extends Tipo{
    @Override
    public String toString(){
        return "IntegerTipo\n";
    }
}
