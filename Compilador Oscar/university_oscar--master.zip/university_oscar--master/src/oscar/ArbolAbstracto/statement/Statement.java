/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package oscar.ArbolAbstracto.statement;

import oscar.ArbolAbstracto.otros.Estatuto;

/**
 *
 * @author OSCAR
 */
public abstract class Statement extends Estatuto{
    public abstract int eval();
}
